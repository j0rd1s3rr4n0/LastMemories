﻿namespace Optimizer
{
    public class FeedApp
    {
        public string Title { get; set; }
        public string Link64 { get; set; }
        public string Link { get; set; }
        public string Tag { get; set; }
        public string Image { get; set; }
        public string Group { get; set; }
    }
}
