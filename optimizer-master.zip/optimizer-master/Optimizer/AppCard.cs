﻿using System.Windows.Forms;

namespace Optimizer
{
    public partial class AppCard : UserControl
    {
        public AppCard()
        {
            InitializeComponent();
        }
    }
}
